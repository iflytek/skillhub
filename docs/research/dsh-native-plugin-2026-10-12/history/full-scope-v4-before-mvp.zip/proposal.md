## Why

SkillHub 已支持将技能安装到 DSH 目录，但用户仍缺少 DSH 内统一的连接、搜索、安装与管理入口。本变更提供一个原生 DSH 插件，在同一会话和界面中完成技能消费，并复用 SkillHub 已有认证、权限、版本和安装契约。

## What Changes

- 在本仓库新增 `plugins/dsh/`，作为独立构建、测试和分发的插件包；用户无需另外安装 SkillHub CLI 或 Bun。
- 提供对话工具、连接配置、技能浏览/详情、已安装管理和工具结果卡片。
- 每次连接一个公共或自建 SkillHub；浏览器 Device Flow 为主，API Token 为备用。
- 支持用户级和项目级安装，默认用户级；远程环境的文件落在 DSH Host，而不是浏览器所在机器。
- 支持检查更新、主动升级和精确卸载；展示 DSH 当前工作区可发现技能，未知来源只读。
- 兼容现有 CLI 安装记录、指纹和目标锁；新增内部复用边界及精确目标保护。
- 只在用户表达查找、安装、管理技能意图时调用 SkillHub；普通任务不额外触发远端搜索。
- 复用 DSH 授权机制；明确意图不额外重复确认，搜索结果需用户选择，本地修改/覆盖冲突需针对影响处理。
- 首版面向 Linux、macOS、Windows 上的 DSH Web，支持本机和远程单用户运行。

## Capabilities

### New Capabilities

- `dsh-registry-connection`: 单实例配置、认证、远程主机边界与凭证隔离。
- `dsh-skill-consumption`: 技能发现、来源识别、完整包安装、加载状态、更新和卸载。
- `dsh-native-experience`: 原生工具、页面、触发规则、授权路径和可安装产物。

### Modified Capabilities

无已归档 capability 的行为修改。现有 CLI 行为应保持兼容；内部复用改动须回归验证。

## Impact

- **Plugin**：新增 Host/Client、测试、配置和独立构建/发布入口。
- **CLI**：增加无副作用的内部消费端入口，复用客户端、安装、metadata、inventory 和锁；补精确目标卸载等必要能力，不默认拆出新 SDK。
- **Backend**：优先复用现有接口。首个验证里程碑核对详情、分页及 Token 权限；若确需接口增量，先在本 change 明确契约并按现有 OpenAPI 流程验证。
- **Documentation**：更新 DSH 集成指南及安装指引；正式行为以本 change 为唯一来源。
- **Compatibility**：不自动迁移 CLI inventory，不修改用户 CLI 的默认 Registry，不要求重建 SkillHub Server/Web 才能发布插件。
- **Out of scope**：DSH 插件市场/托管、技能发布、Suite 编排、多人共用 DSH 的身份隔离、桌面客户端专项适配、无人选择的自动安装/更新、DSH 自动重启。
- **Known limitation**：现有清单对同一技能多个安装目标共享版本。无法在保持清单一致的前提下单独升级目标时明确阻断，不扩大操作范围。

## Decision Record

产品范围来自已确认 Q1–Q12。前期讨论与参考资料见
[澄清记录](../../../docs/research/dsh-native-plugin-2026-10-12/README.md)；
正式行为、设计和实现任务自本 change 起维护在这里。
