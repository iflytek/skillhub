## ADDED Requirements

### Requirement: Plugin SHALL be a self-contained installable DSH package
插件 SHALL 在 SkillHub 仓库 plugins/dsh 中开发并独立打包分发。运行 SHALL NOT 要求用户额外手动安装 SkillHub CLI、Bun 或克隆源码。

#### Scenario: Install a release artifact in a clean environment
- **WHEN** 支持的 DSH 环境安装插件 tarball 或发布包
- **THEN** Host 和 Client 可加载，搜索/安装功能无需 PATH 上存在 skillhub
- **AND** 产物不依赖开发仓库相对路径

#### Scenario: Supported operating systems
- **WHEN** 在固定兼容版本的 Linux、macOS 或 Windows DSH Web 中安装插件
- **THEN** 相应平台的认证、路径与管理行为通过兼容验证
- **AND** 未完成的平台验证如实记录，不以跨平台构建代替运行验收

### Requirement: Plugin SHALL provide native tools and graphical flows
插件 SHALL 提供搜索、详情、安装、列表、更新检查、升级和卸载工具，并提供连接设置、技能浏览/详情和已安装管理界面。工具和界面 SHALL 使用一致的业务服务。

#### Scenario: Browse and manage without terminal commands
- **WHEN** 用户通过插件页面选择技能并执行已授权操作
- **THEN** 操作由 Host 完成，界面显示结构化结果，不要求用户复制终端命令

#### Scenario: Tool output appears in the conversation
- **WHEN** 对话工具返回技能结果
- **THEN** DSH Web 展示可辨识来源和状态的原生卡片或明确的兼容回退
- **AND** Client 不把损坏的结果渲染为成功操作

### Requirement: SkillHub discovery SHALL follow explicit skill-management intent
工具说明和交互 SHALL 在用户表达查找、推荐、安装或管理技能意图时引导使用 SkillHub，不要求用户点名品牌。普通业务任务 SHALL NOT 被插件强制增加远端技能检索。

#### Scenario: User asks for a skill
- **WHEN** 用户说“找一个处理 PDF 的技能”
- **THEN** 可调用 SkillHub 搜索并展示结果供选择

#### Scenario: User asks to summarize a document
- **WHEN** 用户说“总结这份 PDF”，没有查找或管理技能意图
- **THEN** 插件不强制先调用 SkillHub 搜索，也不自动安装技能

#### Scenario: Search returns candidates
- **WHEN** 搜索返回可安装技能但用户尚未选择
- **THEN** 插件不发起安装

### Requirement: Mutation authorization SHALL be consistent across UI and tools
插件 SHALL 复用 DSH 授权机制，不为用户已明确的操作额外增加重复确认。UI SHALL NOT 绕过 Host 的授权及来源/目标保护；冲突确认 SHALL 绑定具体影响。

#### Scenario: Explicit install request
- **WHEN** 用户已明确指定技能及目标，DSH 允许该安装
- **THEN** 插件执行匹配请求，不再只为重复同一授权额外提问

#### Scenario: Host denies a mutation
- **WHEN** 用户点按钮或模型调用工具，但 DSH 策略拒绝修改
- **THEN** 两种入口均不执行写入，并解释拒绝状态

#### Scenario: Selection or conflict is ambiguous
- **WHEN** 有多个同名坐标、目标不明或覆盖计划存在本地修改
- **THEN** 插件要求选择或说明具体影响
- **AND** 不把用户之前的泛化意图视为对全部候选的授权

#### Scenario: UI action has no session context
- **WHEN** 用户从没有绑定会话的全局页面发起技能修改
- **THEN** 插件要求选择可信会话，由 Host 解析 agent/scope 后按宿主策略执行
- **AND** 不伪造 agent，不以无 agent 调用绕过 guard 或审批

#### Scenario: Sessions have different policies
- **WHEN** 两个会话使用同一工作目录但具有不同 agent scope 和工具策略
- **THEN** 页面与工具分别遵循所绑定会话的 allow、deny 和 ask 结果
- **AND** 会话切换使旧操作上下文失效

### Requirement: UI SHALL distinguish operation states and remain accessible
浏览、详情、连接和管理界面 SHALL 覆盖加载、空数据、失败和成功状态，提供中英文和键盘可达的核心操作。状态 SHALL 区分连接成功、登录成功、已安装及加载观察。

#### Scenario: Authentication or network error
- **WHEN** 查询遇到未登录、无权限或网络错误
- **THEN** 展示对应原因和可用恢复入口，不渲染为正常空列表

#### Scenario: Browse installed skills with the keyboard
- **WHEN** 用户只通过键盘查看已安装技能并选择操作
- **THEN** 关键控件有可识别名称、焦点可见且对话框关闭后焦点返回触发点

### Requirement: Connection plugin removal SHALL preserve business skills
禁用或卸载连接插件 SHALL 释放工具、Client 注册和后台轮询；SHALL NOT 自动删除用户已安装的业务技能或修改 CLI 配置。

#### Scenario: Disable the connector
- **WHEN** 用户在 DSH 中禁用 SkillHub 连接插件
- **THEN** 连接插件停止提供功能，已安装技能文件保留
