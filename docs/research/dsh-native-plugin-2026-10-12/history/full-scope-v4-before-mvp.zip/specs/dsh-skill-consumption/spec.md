## ADDED Requirements

### Requirement: Skills SHALL retain full Registry identity
搜索、详情和安装 SHALL 保留 Registry、namespace、slug 和版本身份，展示来源和版本。分页或结果限制 SHALL 如实反映服务端能力，不伪装成全量结果。

#### Scenario: Same slug in different namespaces
- **WHEN** 搜索同时返回 @team-a/report 和 @team-b/report
- **THEN** 两条结果可区分，选择任意一条不会安装另一命名空间的技能

#### Scenario: Review a skill before installation
- **WHEN** 用户打开技能详情
- **THEN** 展示服务端可访问的说明、来源与版本信息
- **AND** 未提供的扫描/评分等信息不被编造为通过或高评分

### Requirement: Installed view SHALL separate discovery from management ownership
插件 SHALL 展示当前工作区内 DSH 可发现的技能，并关联可识别的本地安装记录。可发现、已安装、来源、scope 与可管理权限 SHALL 分开表示；列表操作 SHALL 只读。

#### Scenario: CLI-installed skill
- **WHEN** DSH 发现一个具有一致 SkillHub metadata/inventory 的 CLI 安装
- **THEN** 展示其真实来源、版本和目标，在满足保护规则时允许管理

#### Scenario: Unknown or provider-only origin
- **WHEN** 技能来自手动复制、其他工具或没有本地路径的 provider，且无法验证 SkillHub 归属
- **THEN** 技能仍可展示，管理操作为只读并说明原因
- **AND** 不自动写入所有权记录或删除其内容

#### Scenario: Corrupt installation records
- **WHEN** metadata、inventory 与磁盘冲突或记录损坏
- **THEN** 条目标记不一致，升级/卸载阻断
- **AND** 仅查看列表不触发清单修复

#### Scenario: Same-name skill shadowing
- **WHEN** 多个技能来源同名且宿主只选择其中一个
- **THEN** 展示遵循宿主发现结果，不按名称猜测来源或管理目录
- **AND** 无法枚举的隐藏来源不被宣称已全部展示

#### Scenario: Discovery provider temporarily fails
- **WHEN** 当前上下文的发现快照标记为不完整
- **THEN** 界面显示部分结果，可保留该上下文最近完整快照并标记陈旧
- **AND** 不因缺席而判定技能消失，不借用其他 session/scope 的旧快照，恢复后更新状态

#### Scenario: Different agent scopes discover different skills
- **WHEN** 同一工作目录的两个会话具有不同 agent scope
- **THEN** 插件按可信会话及 scope 读取发现结果，不仅使用 cwd 查询全局层

### Requirement: Installation SHALL commit the complete package to one explicit target
插件 SHALL 支持用户级和项目级安装，默认用户级，并正确处理自定义 DSH_HOME。安装 SHALL 完整保存合法包资源，校验来源、边界和内容指纹，复用与 CLI 一致的目标锁及清单规则。

#### Scenario: Install a resource-bearing skill
- **WHEN** 用户选择合法技能及安装范围
- **THEN** SKILL.md、脚本和引用资源完整安装到选定 Host 目标
- **AND** 插件不执行包内脚本，不修改其他 Agent 或项目

#### Scenario: Invalid package or fingerprint
- **WHEN** 下载包越界、超限、缺少入口或指纹不匹配
- **THEN** 拒绝提交，已有安装保持不变，并展示具体原因

#### Scenario: Concurrent CLI mutation
- **WHEN** CLI 和插件同时操作同一安装目标
- **THEN** 使用一致的目标锁串行化，执行前重新检查记录和内容
- **AND** 不留下表面成功但清单与目录不一致的结果

#### Scenario: Registry package is incompatible with DSH
- **WHEN** 合法 SkillHub 包的名称或 invocation frontmatter 不符合固定 DSH 版本规则
- **THEN** 提交安装前阻断并显示具体兼容性原因，已有目录不变
- **AND** 不静默改写原包，不将该问题显示为等待刷新

#### Scenario: Invocation name and policy differ from registry identity
- **WHEN** 技能调用名称与 Registry slug 不同，或仅允许用户显式调用
- **THEN** 插件分别保留坐标、目录和调用名称，展示模型与用户调用可用性
- **AND** 使用说明尊重宿主 invocation 策略

### Requirement: Installation and loading SHALL have distinct outcomes
插件 SHALL 分别报告文件安装结果与 DSH 发现/加载观察。文件写入成功 SHALL NOT 等同于已加载或执行成功。

#### Scenario: Files installed but session has not discovered them
- **WHEN** 安装成功但当前会话尚未确认发现技能
- **THEN** 显示已安装、加载待确认，并提供宿主支持的下一步
- **AND** 不自动重启 DSH，不捏造激活成功

#### Scenario: Runtime acceptance
- **WHEN** 验收人员安装一个带资源技能并在 DSH 中使用
- **THEN** 证据分别覆盖安装、发现/加载和完成实际任务
- **AND** 仅下载成功不足以通过此场景

### Requirement: Update checks SHALL be read-only and upgrades explicitly scoped
插件 SHALL 支持对指定技能检查更新及主动升级。检查更新 SHALL NOT 修改文件、自动升级、迁移清单或扩展目标；执行 SHALL 重新验证计划。

#### Scenario: Upgrade an eligible single target
- **WHEN** 所选技能有可安装新版且来源、指纹、清单和目标均满足条件
- **THEN** 仅选定目标升级，记录更新，其他技能不变

#### Scenario: Shared inventory version blocks partial upgrade
- **WHEN** 所选目标的新版会与清单中未选目标共享的版本记录冲突
- **THEN** 插件明确说明多目标版本限制，阻断升级并保留所有目标
- **AND** 不静默升级其他 Agent/项目，也不跳过清单保护

#### Scenario: Content changes after checking
- **WHEN** 更新检查后本地文件发生变化
- **THEN** 原计划不能直接执行，插件展示新的影响及冲突
- **AND** 旧确认不授权新计划的覆盖

### Requirement: Uninstall SHALL protect exact targets and provenance
卸载 SHALL 限于被选择且验证可管理的确切目录。插件 SHALL 校验来源、路径和本地变更，并保留其他 Agent、项目和共享所有权。未知来源 SHALL NOT 因同名而被卸载。

#### Scenario: Multiple DSH project installations
- **WHEN** 用户卸载当前项目的某技能，同一用户另一个项目也安装该技能
- **THEN** 只移除当前项目的目标及对应记录，另一个项目保持不变

#### Scenario: Local changes or shared ownership
- **WHEN** 所选目录有本地修改或与 Suite 等共享来源关联
- **THEN** 插件说明具体影响，按受保护计划处理
- **AND** 无法安全表示或保留共享来源时阻断，不递归删除共享内容

#### Scenario: Filesystem commit or recovery fails
- **WHEN** 安装、升级或卸载在写入/恢复阶段失败
- **THEN** 报告实际残留状态及可用恢复信息
- **AND** 不将部分结果报告为全部成功
