## ADDED Requirements

### Requirement: Plugin SHALL connect to one selected Registry
插件 SHALL 支持配置公共或企业自建 SkillHub，每次操作绑定一个活动 Registry 和当前身份，不聚合多个实例。更换连接 SHALL 使旧请求和认证会话失效，且 SHALL NOT 修改用户 CLI 的默认 Registry。

#### Scenario: Switch Registry during a request
- **WHEN** Registry A 的搜索或登录尚未完成，用户切换到 Registry B
- **THEN** A 的后续结果不展示为 B 的数据，A 的凭证不用于 B
- **AND** 已安装技能保留，界面显示 B 的连接与身份状态

#### Scenario: Plugin login coexists with CLI configuration
- **WHEN** 插件成功连接 Registry B，而 CLI 默认连接 Registry A
- **THEN** CLI 默认连接保持 A，插件连接为 B

### Requirement: Plugin SHALL offer browser authorization and Token fallback
插件 SHALL 提供 Device Flow 浏览器授权和 API Token 备用配置。登录 SHALL 在身份核验成功后生效；不支持浏览器授权的服务端 SHALL 获得明确提示及 Token 入口。

#### Scenario: Authorize a remote Host
- **WHEN** 用户通过本机浏览器访问远程 DSH 并选择登录
- **THEN** 浏览器展示验证地址、用户码及有效期，远程 Host 轮询
- **AND** 不依赖远程机器打开图形浏览器，也不要求从浏览器连接远程机器的 localhost

#### Scenario: Cancel or expire authorization
- **WHEN** 用户取消、授权过期/拒绝、切换 Registry 或卸载插件
- **THEN** 轮询终止，不保存未验证凭证，界面展示对应结果

#### Scenario: Use Token fallback
- **WHEN** 用户通过专用设置输入有效 Token
- **THEN** Host 核验身份并保存受保护的连接凭证
- **AND** 无效 Token 不将连接标为已登录

### Requirement: Credentials SHALL remain on the Host
插件 SHALL 将凭证限制在 Host 的受保护存储和必要认证请求中。Token/device code SHALL NOT 出现在模型输入输出、浏览器持久化、普通配置回读或日志中；浏览器表单提交后只保留脱敏状态。

#### Scenario: Read configuration after login
- **WHEN** Client 或模型查询连接状态
- **THEN** 仅返回必要的地址、身份和认证状态，不返回凭证

#### Scenario: Download redirects to another origin
- **WHEN** Registry 提供外域下载地址或响应跨 origin 重定向
- **THEN** Registry Bearer token 不发送给该外域
- **AND** 下载失败不触发隐式切换 Registry 或降低校验

### Requirement: Server permissions SHALL remain authoritative
插件 SHALL 使用当前身份调用 SkillHub 已有权限契约；搜索结果 SHALL NOT 被视为后续安装权限。匿名、无权限和服务不可用 SHALL 区分展示。

#### Scenario: Permission changes after search
- **WHEN** 用户选定搜索结果后，服务端已撤销其访问权限
- **THEN** 安装被拒绝，本地已有技能保持不变，界面提示权限变化

#### Scenario: Offline installed view
- **WHEN** Registry 不可达
- **THEN** 本地已安装信息仍可读取，更新状态显示未知
- **AND** 不将超时显示为“没有技能”或“已是最新版本”

### Requirement: Remote operations SHALL use the DSH Host context
用户级和项目级目标 SHALL 来自 DSH Host 和当前会话工作区。插件 SHALL NOT 把浏览器机器路径或模型传入的任意路径当作安装根。

#### Scenario: Choose project scope without a project
- **WHEN** 当前会话没有可确认的项目根且用户选择项目级
- **THEN** 插件解释缺失的项目上下文，不猜测安装目录

#### Scenario: Switch workspace after preparing an operation
- **WHEN** 操作准备后当前工作区改变
- **THEN** 插件重新确认目标上下文或使原计划失效，不将原计划写入新项目
