# 规格准备与验证记录

日期：2026-10-12。状态：规划产物完成，功能未实现、运行兼容性未验收。

## 用户选择覆盖

| 选择 | 正式规格落点 |
| --- | --- |
| Q1 B：工具、连接设置、浏览管理页面 | dsh-native-experience：native tools and graphical flows |
| Q2 B：安装、列表、检查更新、升级、卸载 | dsh-skill-consumption：installation / updates / uninstall |
| Q3 B：单活动公共或自建 Registry | dsh-registry-connection：one selected Registry |
| Q4 B：本机及远程单用户 | dsh-registry-connection：remote Host context / browser authorization |
| Q5 B：同仓库独立模块 | dsh-native-experience：self-contained installable package |
| Q6 B：用户与项目范围，默认用户级 | dsh-skill-consumption：explicit target |
| Q7 B：浏览器授权 + Token | dsh-registry-connection：browser authorization and Token fallback |
| Q8 A：复用 DSH 授权，不重复询问 | dsh-native-experience：consistent mutation authorization |
| Q9 A：无需手动安装 CLI | dsh-native-experience：clean environment installation |
| Q10 A：Linux/macOS/Windows DSH Web | dsh-native-experience：supported operating systems |
| Q11 B：可发现技能展示、来源识别和只读边界 | dsh-skill-consumption：discovery versus ownership |
| Q12 A：明确技能管理意图触发 | dsh-native-experience：explicit skill-management intent |

## 当前证据

- 阅读现有 CLI 的 client、auth、install、remove、metadata、inventory、upgrade 和目标锁实现；源码证据及复用约束见 design.md。
- 官方 DSH 与社区参考资料为源码/文档调查，引用见 design.md 和研究记录；未将其当作运行验收。
- `openspec validate add-dsh-native-plugin --strict --no-interactive`：通过。
- `openspec status --change add-dsh-native-plugin`：proposal/specs/design/tasks 四项规划产物齐全。
- 本 change 的 Markdown 本地链接与行尾空白检查：通过；仅做文件级检查，不验证外部服务可用性。
- 实施前综合文档已补齐到 [design.md](design.md)：12 项确认决策、功能说明、架构、实现方案、阶段和验收；包含 6 个 Mermaid 图块。
- 综合文档及两个更新的调研入口通过本地链接、代码围栏与决策覆盖检查；正式规格仍为 17 项需求、41 个场景，严格 OpenSpec 校验通过。Mermaid 仅检查文本结构，尚未执行渲染器语法校验或图形预览。

## 明确未验证

插件代码、可安装包、真实 DSH 加载、登录和模型调用均未实现或运行。
三平台和远程 DSH 验收未执行；所有实现任务保持未勾选。
DSH 实际兼容发行版本、Client 构建、UI 授权、发现/加载观察能力须在 tasks.md 第 0 阶段核验。
未 push、创建 PR、打 tag、发布 npm 包、部署服务或执行生产请求。

规格通过表示计划可继续执行，不表示插件已完成。

## 独立评审后的产品设计补充

- 新增 [产品交互与页面设计](product-design.md) 和四视图设计图，区分首次设置、页面浏览、对话入口和统一管理；这些是拟议交互，未冒充宿主运行截图。
- 采纳评审三项修订：可信 session/agent scope、安装前 DSH 格式与 invocation 兼容性、不完整发现及陈旧结果。
- 增加 6 个验收场景，规格现为 17 项需求、47 个场景；同步更新设计和 M0/实现任务，均未勾选实施完成。
- 设计图使用内置 imagegen，已检查图中文字及关键状态；图中通用宿主侧栏为示意，产品建议仍以两个面板页签为准。模型版本不可验证。
- 本轮严格 OpenSpec 校验、本地链接与围栏检查通过。新增 Mermaid 流程未执行实际渲染。未安装 DSH、运行插件或执行生产操作。

## v3 宿主交互修正

- 用户指出 v2 与真实 DSH 产品脱节；确认问题成立，撤下正文 v2，保留文件作为历史稿。
- 阅读官方 ui-sidebar、ui-layout、ui-plugin-manager 文档与注册源码，固定提交 d743267388641bc76f17c45ce8b4c231aed1d32c；核对官方截图/素材与第三方实机截图。
- 三张 v3 图以真实 DSH 截图为编辑底图，保留工作区、会话及宿主结构；来源和许可见 assets/host-reference/README.md。
- 未启动真实 DSH；v3 是参考图编辑产物，不是插件运行截图。图中选择态和控件细节不能替代组件实测。

## v4 功能交互优化（2026-10-13）

- 用户初步认可 v3 宿主结构，要求进一步结合功能优化；按用户选择不创建 Trellis 任务，继续维护现有 OpenSpec。
- 更新 product-design.md：浏览与安装、已安装精确目标管理、对话卡片双结果、连接授权等待；补充状态矩阵、返回上下文、地址草稿、历史动作、窄窗口及键盘要求。
- 生成并目视检查四张 v4 图；发现对话历史卡片在安装成功后仍显示可点击安装，进行一次定向修订，最终为“已安装”禁用状态。
- v4 图片与提示词保存在 assets/，沿用 v3 的宿主参考，不新增未核实的 DSH API。内置 imagegen 不暴露模型版本。
- 没有增加正式功能范围；capability 规格保持 17 项需求、47 个场景。交互实现验收追加至 tasks.md 4.7，未勾选完成。
- 文档/图片验证与运行验证分开：未开发插件、未运行真实交互、未验证窄窗口/无障碍/三平台；图中宿主选择态和控件细节以实际组件为准。
